package com.ems;

public interface CalculatorService {
	public int additionService(int number,int number2);

}
