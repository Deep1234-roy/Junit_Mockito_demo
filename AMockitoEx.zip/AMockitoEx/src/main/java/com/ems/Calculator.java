package com.ems;

public class Calculator {
	
	CalculatorService calService;
	
	public Calculator(CalculatorService calService) {
		this.calService=calService;
	}
	
	public int addition(int number1 , int number2) {
		
		
		return calService.additionService(number1, number2);
		
		//return number1+number2;
		
	}

}
