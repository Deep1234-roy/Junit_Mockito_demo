package com.ems;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AMockitoExApplication {

	public static void main(String[] args) {
		SpringApplication.run(AMockitoExApplication.class, args);
	}

}
