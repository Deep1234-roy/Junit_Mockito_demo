package com.ems;

import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AMockitoExApplicationTests {

	Calculator cal =null;
	
	
	//create a mock object
	//CalculatorService service = Mockito.mock(CalculatorService.class);
	
	@Mock
	CalculatorService service;
//	//Stubbed Object
//	CalculatorService service=new CalculatorService() {	
//		@Override
//		public int additionService(int number, int number2) {
//			
//			return number+number2;
//		}
//	};
//	
	@BeforeEach
	public void setUp() {
		cal= new Calculator(service);
	}
	
	@Test
	@DisplayName("Test Addition of Two Numbers")
	public void test_AdditionOfTwoNumbers() {
		when(service.additionService(2, 3)).thenReturn(5);
		Assertions.assertEquals(5, cal.addition(2, 3));
		verify(service).additionService(2, 3);
	}

}
