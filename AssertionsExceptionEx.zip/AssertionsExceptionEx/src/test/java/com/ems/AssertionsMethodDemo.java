package com.ems;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class AssertionsMethodDemo {
	
	
	//assertArrayEqual
	@Test
	@Disabled
	public void test_TwoArraysAreEquals() {
		char [] expected_outout= {'J','o','h','n'};
		char [] actual_output="John".toCharArray();
		//assertThat(actual_output).isEqualTo(actual_output);
		Assertions.assertArrayEquals(expected_outout, actual_output,"Both Arrays aren't Equal");
	}
	
	//assertEqual
	@Test
	@DisplayName("Check values are equals")
	@Disabled
	public void testTwoValuesAreEqual() {
		long expected_outout =12345666;
		long actual_output =1234566;
		Assertions.assertEquals(expected_outout, actual_output);
	}
	@Test
	//assertTrue
	@Disabled
	public void testAssretTrueMethodWithSimpleCondition() {
		Assertions.assertTrue(5>4,"5 is greater than 4");
	}
	
	//assertFalse
	@Test
	@Disabled
	public void testAssretFalseMethodWithSimpleCondition() {
		Assertions.assertFalse(5<4,"4 is less than 5");
	}
	//NotNull
	@Test
	public void whenAssertingNotNull_thenTrue() {
	    Object dog = new Object();
	    Assertions.assertNotNull(dog, () -> "The dog should not be null");
	}
	
	
	//Null
	@Test
	public void whenAssertingNull_thenTrue() {
	    Object cat = null;
	    Assertions.assertNull(cat, () -> "The cat should be null");
	    
	    //Assertions.assertThrow
	}


	
	

}
