package com.ems;

public class TestClass {

	public static void main(String[] args) {
		String id="1234a";
		int eid= Integer.parseInt(id);
		System.out.println(eid);
	}
}
