package com.Operation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FixtureExApplicationTests {

	@Test
	void contextLoads() {
	}

}
