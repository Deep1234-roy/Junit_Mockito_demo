package com.Operation;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

@TestMethodOrder(MethodOrderer.MethodName.class)
public class AlphanumericOrderEx {

	private static StringBuilder myString = new StringBuilder("");
	
	@Test
	@DisplayName("This is A test")
	public void myATest() {
		myString.append("A");
	}
	
	@Test
	@DisplayName("This is B test")
	public void myBTest() {
		myString.append("B");
	}
	
	@Test
	@DisplayName("This is a test")
	public void myaTest() {
		myString.append("a");
	}
	
	//ABa   BAa
	@AfterAll
	public static void testFinalOutput() {
		assertThat(myString.toString()).isEqualTo("ABa");
	}
}
