package com.Operation;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;

public class BeforeAndAfterAllDemo {
	
	
	@BeforeAll
	public static void getDatabaseConnectionObject() {
		System.out.println("Database object is created");
	}
	
	@Test
	//@Disabled
	public void testIsEmployeePresentInDatabase() {
		String actual_value="Abc";
		String expected_value="Abc";
		assertThat(actual_value).isEqualTo(expected_value);	
		System.out.println("Yes Employee is present");
	}
	@Test
	public void testIsEmployeeAgeLessThan18() {
		System.out.println("All employees greater than 18 years old");
		
	}
	
	@AfterAll
	public static void closeDatabaseConnection() {
		System.out.println("Database object is closed");
	}

}
