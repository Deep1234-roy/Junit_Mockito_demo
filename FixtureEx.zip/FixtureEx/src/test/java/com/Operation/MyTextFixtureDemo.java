package com.Operation;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class MyTextFixtureDemo {
	@BeforeEach
    public void initMethod() {
    System.out.println("_______________________________________________________\n");
        System.out.println("This is the setUp() method that runs before each testcase");
    }
    @Test
    public void test_JUnit1() {
        System.out.println("This is the testcase test_JUnit1() in this class");
    }
    @Test
    public void test_JUnit2() {
        System.out.println("This is the testcase test_JUnit2() in this class");
    }
 
    @Test
    public void test_JUnit3() {
        System.out.println("This is the testcase test_JUnit3() in this class");
    }
    @AfterEach
    public void myDestroy() {
        System.out.println("This is the tearDown() method that runs after each testcase");
        System.out.println("_______________________________________________________\n");
    }


}
