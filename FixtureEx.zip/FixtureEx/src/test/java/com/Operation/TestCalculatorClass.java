package com.Operation;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TestCalculatorClass {
	
	Calculator cal;
	
	@BeforeEach
	public void createCalObject() {
		cal = new Calculator();
		System.out.println("Object Initialized");
	}
	
	@Test
	public void test_SumOfTwoNumbers1() {
		int actual_output=cal.sum(12, 12);
		int expected_output=24;
		assertThat(actual_output).isEqualTo(expected_output);
		System.out.println("Result of this Test ="+actual_output);
		
	}
	@Test
	public void test_AdditionOfTwoNumbers2() {
		int actual_output=cal.sum(134, 134);
		int expected_output=268;
		assertThat(actual_output).isEqualTo(expected_output);
		System.out.println("Result of this Test ="+actual_output);
		
	}
	@Test
	public void isAdult_AgeLessThan18_False() {
		
	}
	
	@AfterEach
	public void clearCalObject() {
		cal=null;
		System.out.println("Object is cleared");
	}
	
	@Test
	public void test_sumOfNegativesNumber() {
		
	}

}
