package com.ems;

import org.junit.platform.suite.api.SelectClasses;
import org.junit.platform.suite.api.SelectPackages;
import org.junit.platform.suite.api.Suite;

import com.ems.serviceTest.EmployeeServiceTest;
import com.ems.serviceTest.NewTest.EmployeeServiceNewTest;

@Suite
//@SelectPackages({"com.ems.serviceTest","com.serviceTest.NewTest"})
@SelectClasses({EmployeeServiceTest.class,EmployeeServiceNewTest.class})
public class TestSuiteSelectMultiplePackagesAndClasses {

}
