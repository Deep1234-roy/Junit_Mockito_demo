package com.ems;

import org.junit.platform.suite.api.IncludePackages;
import org.junit.platform.suite.api.SelectPackages;
import org.junit.platform.suite.api.Suite;

@Suite
@SelectPackages("com.ems.serviceTest")
@IncludePackages("com.ems.serviceTest.NewTest")
public class TestSuiteWithIncludePackage {

}
