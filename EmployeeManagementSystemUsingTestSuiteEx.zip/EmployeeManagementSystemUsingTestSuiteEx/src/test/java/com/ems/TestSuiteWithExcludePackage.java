package com.ems;

import org.junit.platform.suite.api.ExcludePackages;
import org.junit.platform.suite.api.SelectPackages;
import org.junit.platform.suite.api.Suite;

@Suite
@SelectPackages("com.ems.serviceTest")
@ExcludePackages("com.ems.serviceTest.NewTest")
public class TestSuiteWithExcludePackage {

}
