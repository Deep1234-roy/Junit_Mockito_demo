package com.ems.serviceTest.NewTest;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

import com.ems.service.EmployeeService;

@DisplayName("All test cases in com.serviceTest.NewTest package ")
public class EmployeeServiceNewTest {
	
	EmployeeService obj;
	
	@Test
	@DisplayName("Check whether given string is present in Name")
	public void testEmployeeName() {
		assertThat("Bhushan").contains("Bhu");
	}
	@Nested
	@DisplayName("new test cases with new values")
	class NewEmployeeServiceTestClass{
		
		@BeforeEach
		public void setUp() {
			obj=new EmployeeService();
		}
		
		@Test
		public void testCalculateSalaryFromGivenBasicSalary() {
			assertThat(obj.calculateSalary(2000)).isEqualTo(3200);
			
		}
				
		@Test
		public void testGetFullNameOfEmployee() {
			assertThat(obj.getFullName("Rakshit","M")).isEqualTo("Rakshit M");
		}
		
		@Test
		@Tag("dev")
		public void testIsEmployeesAgeGreaterThan18True() {
			assertThat(obj.isEmployeeAgeGreaterThan18(24)).isEqualTo(true);
		}
		
		@AfterEach
		public void tearDown() {
			obj=null;
		}
		
		
		
	}
	
	

}
