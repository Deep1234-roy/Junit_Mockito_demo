package com.ems.serviceTest;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import com.ems.service.EmployeeService;

@DisplayName("All test cases in com.service.test package ")
public class EmployeeServiceTest {
	
	
	EmployeeService obj;
	@BeforeEach
	public void setUp() {
		obj=new EmployeeService();
	}
	
	@Test
	@Tag("dev")
	public void testCalculateSalaryFromGivenBasicSalary() {
		assertThat(obj.calculateSalary(2000)).isEqualTo(3200);
		
	}
	
	
	@Test
	@Tag("dev")
	public void testGetFullNameOfEmployee() {
		assertThat(obj.getFullName("Bhushan","Kumar")).isEqualTo("Bhushan Kumar");
	}
	
	@Test
	public void testIsEmployeesAgeGreaterThan18True() {
		assertThat(obj.isEmployeeAgeGreaterThan18(22)).isEqualTo(true);
	}
	
	@ParameterizedTest
	@ValueSource(ints= {12,14,24,36,44,22,46})
	@DisplayName("Parameterized Test Demo")
	public void isGivenNumberIsEvenNumber(int mynumber) {
		assertThat(EmployeeService.isEvenNumber(mynumber)).isEqualTo(true);
	}
	
	
	@ParameterizedTest
	@ValueSource(strings ={"madam","dad","radar","hello"})
	@DisplayName("Palindrome Test")
	public void isGivenStringInPalindrome(String word) {
		
		assertThat(EmployeeService.isWordPalindrome(word)).isEqualTo(true);
		
	}
	
	
	@AfterEach
	public void tearDown() {
		obj=null;
	}
	
	

}
