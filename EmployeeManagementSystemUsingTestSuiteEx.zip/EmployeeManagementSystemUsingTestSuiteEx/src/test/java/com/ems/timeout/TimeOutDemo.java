package com.ems.timeout;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.concurrent.TimeUnit;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Timeout;

@Timeout(1)
public class TimeOutDemo {
	
	@BeforeEach
	public void setUp() {
		System.out.println("Executed");
	}
	
	@Test
	//@Timeout(1)
	public void isTestTrue() throws InterruptedException {
		for (int i = 0; i < 20; i++) {
			//Thread.sleep(300);
			System.out.println(i);
		}
		assertThat(true).isEqualTo(true);
	}
	
	@Test
	public void isFalseTest() throws InterruptedException {
		TimeUnit.SECONDS.sleep(2);
		assertThat(false).isEqualTo(false);
	}
	

}
