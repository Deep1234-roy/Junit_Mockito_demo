package com.ems.service;

public class EmployeeService {

	public double calculateSalary(double basic_salary) {

		return basic_salary + (basic_salary * .6);
	}

	public String getFullName(String first_name, String last_name) {
		return first_name + " " + last_name;
	}

	public boolean isEmployeeAgeGreaterThan18(int age) {
		if (age > 18)
			return true;
		else
			return false;
	}

	public static boolean isEvenNumber(int number) {
		if (number % 2 == 0)
			return true;
		else
			return false;
	}
	
	//dad 
	
	public static boolean isWordPalindrome(String word) {
		
		return new StringBuffer(word).reverse().toString().equals(word) ;
	}

}
