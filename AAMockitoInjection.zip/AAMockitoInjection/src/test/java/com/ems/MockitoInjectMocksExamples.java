package com.ems;

import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;

public class MockitoInjectMocksExamples extends BaseTestCase {
@Mock EmailService emailService;
	
	@Mock SMSService smsService;
	
	@InjectMocks AppServices appServicesConstructorInjectionMock;
	
//	@InjectMocks AppServices1 appServicesSetterInjectionMock;
//	
//	@InjectMocks AppServices2 appServicesFieldInjectionMock;
	
	@Test
	void test_constructor_injection_mock() {
		when(appServicesConstructorInjectionMock.sendEmail("Email")).thenReturn(true);
		when(appServicesConstructorInjectionMock.sendSMS("SMS")).thenReturn(true);
		
		Assertions.assertTrue(appServicesConstructorInjectionMock.sendEmail("Email"));
		Assertions.assertFalse(appServicesConstructorInjectionMock.sendEmail("Unstubbed Email"));
		
		Assertions.assertTrue(appServicesConstructorInjectionMock.sendSMS("SMS"));
		
	}
}

