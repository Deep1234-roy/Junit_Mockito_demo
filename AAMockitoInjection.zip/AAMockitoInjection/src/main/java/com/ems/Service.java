package com.ems;

public interface Service {
	
	//first I have created a service
	public boolean send(String msg);
}
