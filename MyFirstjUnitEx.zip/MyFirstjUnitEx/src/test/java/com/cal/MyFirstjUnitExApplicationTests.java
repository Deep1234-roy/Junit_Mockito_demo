package com.cal;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyFirstjUnitExApplicationTests {
	private Calculator cal = new Calculator();
	private ArrayBaseFunctions  abf = new ArrayBaseFunctions();
	
	@Test
	@Disabled
	void contextLoads() {
	}
	
	@Test
	void testAddition() {
		//test addition method
		//example - 20, 30 ,50
		int actual_result = cal.addition(20, 30, 50);
		int expected_result=100;
		assertThat(actual_result).isEqualTo(expected_result);	
	}
	
	@Test
	void testFullName() {
		//example "Bhushan Kumar"
		String expected_value="Bhushan Kumar ";
		String actual_value = cal.fullName("Bhushan", "Kumar");
		assertThat(actual_value).isEqualTo(expected_value);
	}
	
	@Test
	void testIsNameEmpty() {
		boolean actual_result = cal.isNameEmpty("");
		assertThat(actual_result).isTrue();
	}
	
	@Test
	void testAddArrayElement() {
		// in my array --> 2 3 4
		// expected result -->9
		int arr[] = {2,3,4};
		int actual_value = abf.addElementsInArray(arr);
		int expected_value=9;
		assertThat(actual_value).isEqualTo(expected_value);
	}
	
	@Test
	void testArrayItemLessThanTwenty() {
		int arr[] = {12,13,14};
		boolean actual_result = abf.arralyElementsGreaterThanTwenty(arr);
		boolean expected_result =false;
		assertThat(actual_result).isEqualTo(expected_result);
	}

}
