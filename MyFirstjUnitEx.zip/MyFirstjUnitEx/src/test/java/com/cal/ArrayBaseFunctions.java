package com.cal;

import java.util.Iterator;

public class ArrayBaseFunctions {
	
	public int addElementsInArray(int arr[]) {
		int result=0;
		for (int i = 0; i < arr.length; i++) {
			result +=arr[i];
		}
		return result;
	}
	public boolean arralyElementsGreaterThanTwenty(int arr[]) {
		
		boolean result =false;
		for(int element :arr) {
			if(element>20) {
				result=true;
			}
			else {
				result=false;
			}
		}
		
		return result;
	}
	

}
//requirement 
// [4,5,7]