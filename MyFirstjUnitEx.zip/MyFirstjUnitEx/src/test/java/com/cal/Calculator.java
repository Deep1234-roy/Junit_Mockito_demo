package com.cal;

public class Calculator {
	
	
	//we have to write unit test case for this method
	public int addition(int num1, int num2, int num3) {
		return num1+num2+num3;
		
	}
	
	public String fullName(String first_name, String last_name) {
		
		return first_name+" "+last_name+" ";
	}
	 
	
	public boolean isNameEmpty(String name) {
		return name.isEmpty();
	}
	

}
